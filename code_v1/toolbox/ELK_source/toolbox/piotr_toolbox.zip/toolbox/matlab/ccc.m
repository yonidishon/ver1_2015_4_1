% clear, close all, clc, clear global
%
% USAGE
%  ccc
%
% INPUTS
%
% OUTPUTS
%
% EXAMPLE
%
% See also C, CC
%
% Piotr's Image&Video Toolbox      Version 1.5
% Copyright 2012 Piotr Dollar.  [pdollar-at-caltech.edu]
% Please email me if you find bugs, or have suggestions or questions!
% Licensed under the Simplified BSD License [see external/bsd.txt]

clear; close all; clc; clear all;
